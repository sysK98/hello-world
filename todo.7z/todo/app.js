var todoList = [
    { done: true, title: "AngularJS 학습"},
    { done: false, title: "TEPS 학습"},
    { done: true, title: "jQuery 스터디"},
    { done: false, title: "프로젝트 구상"}
];
 
var app = angular.module("todo",[]).controller("todoCtrl", function($scope) {
    $scope.appName = 'AngJS ToDo App';
    $scope.todoList = todoList;    
});
 